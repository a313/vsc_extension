🌟 Features

🔨 Generate folder & files with structure easily.
  * Supported GetX
  * Supported Freezed
