import { camelize, toSnake } from "./util";





export class GetXGenerate {

    generateController(name: string) {
        const filename = toSnake(name);
        const camel = camelize(name);


        const content = `
import 'package:get/get.dart';


class ${camel}Controller extends GetxController {
  
}
`;
        return content;
    }


    generateBinding(name: string) {
        const filename = toSnake(name);
        const camel = camelize(name);


        const content = `
import 'package:get/get.dart';
import '${filename}_controller.dart';

class ${camel}Binding implements Bindings {
   	@override
  	void dependencies() {
    	Get.lazyPut<${camel}Controller>(() => ${camel}Controller());
  	}
}
`;
        return content;
    }

    generatePage(name: string) {
        const filename = toSnake(name);
        const camel = camelize(name);


        const content = `
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '${filename}_controller.dart';


class ${camel}Page extends GetView<${camel}Controller> {
	const ${camel}Page({Key? key}) : super(key: key);
	
	@override
  	Widget build(BuildContext context) {
		return Container();
  	}
}
`;
        return content;
    }
}