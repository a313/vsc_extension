import { camelize, toSnake } from "./util";





export class FreezedGenerate {

    generateFile(name: string, doJson: boolean) {
        const filename = toSnake(name);
        const camel = camelize(name);
        const entity = camel.replace('Model', '');
        const jsonImport = doJson ? `part '${filename}.g.dart';` : "";
        const jsonConstr = doJson ? `
  factory ${camel}.fromJson(Map<String, dynamic> json) =>
			_$${camel}FromJson(json);` : "";

        const content = `
import 'package:freezed_annotation/freezed_annotation.dart';
part '${filename}.freezed.dart';
${jsonImport}
@freezed
abstract class ${camel} extends ${entity} with _$${camel} {
  factory ${camel}(
    //Entity constructor
  ) = _${camel};
  
	${jsonConstr}
}
`;
        return content;
    }
}
