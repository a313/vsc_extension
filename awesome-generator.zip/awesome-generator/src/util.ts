import * as vscode from 'vscode';
import p = require('path');
export function toSnake(value: string) {
    return value
        .replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`)
        .toLowerCase()
        .replace(/^_/, '');
}

export function camelize(str: string) {
    return str.replace(/^([a-z])|((?:[\s_])[a-z])/g, function (match, _index) {
        if (+match === 0) { return ""; } // or if (/\s+/.test(match)) for white spaces
        return match.toUpperCase().replace(/[\s_]/g, (_, __) => "");
    });
}

export async function getInputName(): Promise<string | undefined> {
    // The code you place here will be executed every time your command is executed

    // Display a message box to the user
    const nameOpts: vscode.InputBoxOptions = {
        prompt: "Choose a name for your class",
        validateInput: async (value) => {
            return /^[0-9a-zA-Z_]+$/g.test(value) ? null : "It is not a valid class name !";
        }

    };
    const name = await vscode.window.showInputBox(nameOpts);
    if (name === undefined) {
        vscode.window.showErrorMessage("Aborted");
        return undefined;
    }
    return name;
}

export async function getUri(): Promise<vscode.Uri | undefined> {

    const openOpts: vscode.OpenDialogOptions = { canSelectMany: false, canSelectFiles: false, canSelectFolders: true };
    const userUri = await vscode.window.showOpenDialog(openOpts);
    if (userUri === undefined) {
        vscode.window.showErrorMessage("Aborted");
        return undefined;
    }
    return userUri[0];

}

