import * as vscode from 'vscode';
import { FreezedGenerate } from "./freezed_genarate";
import { GetXGenerate } from "./getx_genarate";
import { camelize, getInputName, getUri, toSnake } from './util';
import p = require('path');
import fs = require('fs');
import cp = require('child_process');

export function activate(context: vscode.ExtensionContext) {
	let getX = vscode.commands.registerCommand('awesome-generator.generate_getx', () => generateGetXFolder(undefined));
	let getXContext =
		vscode.commands.registerCommand('awesome-generator.generate_getx_context', (inUri: vscode.Uri) => generateGetXFolder(inUri));


	let freezed = vscode.commands.registerCommand('awesome-generator.generate_freezed', () => generateFreezed(undefined));
	let freezedContext =
		vscode.commands.registerCommand('awesome-generator.generate_freezed_context', (inUri: vscode.Uri) => generateFreezed(inUri));

	context.subscriptions.push(getXContext, getX, freezed, freezedContext);
}

async function generateGetXFolder(inUri: vscode.Uri | undefined) {
	var name = await getInputName();
	var uri = inUri ?? await getUri();
	if (uri === undefined || name === undefined) return;
	const getx = new GetXGenerate();
	var folderPath = p.join(uri.path, toSnake(name));
	fs.mkdirSync(folderPath);

	var controllerPath = p.join(folderPath, toSnake(name) + '_controller.dart');
	fs.writeFileSync(controllerPath, getx.generateController(name), 'utf8');

	var bindingPath = p.join(folderPath, toSnake(name) + '_binding.dart');
	fs.writeFileSync(bindingPath, getx.generateBinding(name), 'utf8');

	var pagePath = p.join(folderPath, toSnake(name) + '_page.dart');
	fs.writeFileSync(pagePath, getx.generatePage(name), 'utf8');

	var openPath = vscode.Uri.parse("file:///" + pagePath); //A request file path
	vscode.workspace.openTextDocument(openPath).then(doc => {
		vscode.window.showTextDocument(doc);
		vscode.window.showInformationMessage("Successfully generated " + camelize(name!) + " class.", "Okay");
	});
}
interface BooleanQuickPickItem extends vscode.QuickPickItem { value: boolean }
async function generateFreezed(inUri: vscode.Uri | undefined) {
	var name = await getInputName();
	var uri = inUri ?? await getUri();
	if (uri === undefined || name === undefined) return;
	const freezed = new FreezedGenerate();
	var filePath = p.join(uri.fsPath, toSnake(name) + '.dart');
	const doJson: readonly BooleanQuickPickItem[] = await new Promise((res) => {
		const quickpick = vscode.window.createQuickPick<BooleanQuickPickItem>();
		const items = [{ label: "Yes", value: true }, { label: "No", value: false }];
		quickpick.title = "Add toJSON/fromJSON methods ?";
		quickpick.items = items;
		quickpick.onDidAccept(() => quickpick.hide());
		quickpick.onDidHide(() => { res(quickpick.selectedItems); quickpick.dispose(); });
		quickpick.show();
	});

	if (doJson === undefined || doJson.length === 0) {
		vscode.window.showErrorMessage("Aborted");
		return;
	}

	fs.writeFileSync(filePath, freezed.generateFile(name, doJson[0].value), 'utf8');

	var openPath = vscode.Uri.parse("file:///" + filePath); //A request file path
	vscode.workspace.openTextDocument(openPath).then(doc => {
		vscode.window.showTextDocument(doc);
		vscode.window.showInformationMessage("Successfully generated " + camelize(name ?? '') + " class.", "Okay");
	});
}




